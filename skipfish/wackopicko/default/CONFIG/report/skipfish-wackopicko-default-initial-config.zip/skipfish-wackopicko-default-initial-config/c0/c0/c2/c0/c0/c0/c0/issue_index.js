var issue = [
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 340, 'decl_mime': 'text/plain', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10802, 'sid': '0', 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 340, 'decl_mime': 'text/plain', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i1' }
];
