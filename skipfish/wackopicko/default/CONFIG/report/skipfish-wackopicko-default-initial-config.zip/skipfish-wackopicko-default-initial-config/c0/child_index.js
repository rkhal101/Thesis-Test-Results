var child = [
  { 'dupe': false, 'type': 4, 'name': 'WackoPicko', 'dir': 'c0', 'linked': 5, 'url': 'http://192.168.0.26/WackoPicko/', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': true, 'child_cnt': 176, 'issue_cnt': [ 158, 4, 35, 40, 1 ], 'sig': 0x2150d2e },
  { 'dupe': false, 'type': 4, 'name': 'WackoPicko', 'dir': 'c1', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': true, 'child_cnt': 1, 'issue_cnt': [ 5, 0, 1, 0, 0 ], 'sig': 0x7260df9f },
];
