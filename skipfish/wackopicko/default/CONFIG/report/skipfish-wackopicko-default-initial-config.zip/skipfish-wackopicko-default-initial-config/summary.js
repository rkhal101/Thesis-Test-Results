var sf_version = '2.10b';
var scan_date  = 'Mon Aug  6 23:28:10 2018';
var scan_seed  = '0x106cb24d';
var scan_ms    = 359834;
