var child = [
  { 'dupe': false, 'type': 64, 'name': 'picid=7', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/pictures/view.php?picid=7', 'fetched': true, 'code': 303, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xffbfffff }
];
