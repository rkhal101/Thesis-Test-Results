var child = [
  { 'dupe': false, 'type': 4, 'name': 'WackoPicko', 'dir': 'c0', 'linked': 5, 'url': 'http://192.168.0.26/WackoPicko/', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': true, 'child_cnt': 122, 'issue_cnt': [ 100, 0, 27, 27, 4 ], 'sig': 0x54533b07 }
];
