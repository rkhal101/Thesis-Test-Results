var child = [
  { 'dupe': false, 'type': 4, 'name': 'doggie', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/doggie/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 4, 'name': 'flowers', 'dir': 'c1', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/flowers/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 2, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 4, 'name': 'house', 'dir': 'c2', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/house/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 3, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 4, 'name': 'toga', 'dir': 'c3', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/toga/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 2, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 4, 'name': 'waterfall', 'dir': 'c4', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/waterfall/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
