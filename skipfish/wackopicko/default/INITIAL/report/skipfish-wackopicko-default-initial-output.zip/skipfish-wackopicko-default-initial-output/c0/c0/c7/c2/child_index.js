var child = [
  { 'dupe': false, 'type': 32, 'name': 'hodjjgld.128_128.jpg', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/house/hodjjgld.128_128.jpg', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'My_House.128_128.jpg', 'dir': 'c1', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/house/My_House.128_128.jpg', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'our_house.128_128.jpg', 'dir': 'c2', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/house/our_house.128_128.jpg', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
