var child = [
  { 'dupe': false, 'type': 32, 'name': 'flowers.128_128.jpg', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/flowers/flowers.128_128.jpg', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'flweofoee.128_128.jpg', 'dir': 'c1', 'linked': 2, 'url': 'http://192.168.0.26/WackoPicko/upload/flowers/flweofoee.128_128.jpg', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
