var child = [
  { 'dupe': false, 'type': 64, 'name': 'query=1', 'dir': 'c0', 'linked': 5, 'url': 'http://192.168.0.26/WackoPicko/pictures/search.php?query=1', 'fetched': true, 'code': 200, 'len': 2614, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 2, 0, 2, 2, 0 ], 'sig': 0xdf4e16ed }
];
