var sf_version = '2.10b';
var scan_date  = 'Mon Aug  6 22:58:44 2018';
var scan_seed  = '0x0a2015e2';
var scan_ms    = 183569;
