var child = [
  { 'dupe': false, 'type': 2, 'name': 'http://192.168.0.26/', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.0.26/', 'fetched': true, 'code': 200, 'len': 28067, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': '[none]', 'missing': false, 'csens': true, 'child_cnt': 123, 'issue_cnt': [ 104, 0, 27, 27, 4 ], 'sig': 0x9a0de39b }
];
