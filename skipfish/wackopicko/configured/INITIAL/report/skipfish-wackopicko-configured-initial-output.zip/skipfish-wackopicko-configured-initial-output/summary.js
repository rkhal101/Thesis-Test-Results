var sf_version = '2.10b';
var scan_date  = 'Sun Aug  5 00:59:54 2018';
var scan_seed  = '0x7babee58';
var scan_ms    = 2208187;
