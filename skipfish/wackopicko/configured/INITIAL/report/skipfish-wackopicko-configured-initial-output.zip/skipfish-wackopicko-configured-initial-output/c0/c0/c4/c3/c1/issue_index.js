var issue = [
  { 'severity': 4, 'type': 50107, 'sid': '0', 'extra': 'remote file inclusion', 'fetched': true, 'code': 200, 'len': 286, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 3, 'type': 40501, 'sid': '0', 'extra': 'responses for ./val and .../val look different', 'fetched': true, 'code': 200, 'len': 277, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 277, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10602, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 277, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i3' }
];
