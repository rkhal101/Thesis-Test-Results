var issue = [
  { 'severity': 0, 'type': 10404, 'sid': '0', 'extra': 'Directory listing', 'fetched': true, 'code': 200, 'len': 1273, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i0' }
];
