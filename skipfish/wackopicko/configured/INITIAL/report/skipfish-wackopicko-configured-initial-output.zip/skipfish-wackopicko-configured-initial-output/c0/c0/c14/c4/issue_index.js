var issue = [
  { 'severity': 2, 'type': 30601, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 4197, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 4197, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 200, 'len': 4197, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i2' }
];
