var issue = [
  { 'severity': 0, 'type': 10405, 'sid': '0', 'extra': '', 'fetched': false, 'error': 'Content not fetched', 'dir': 'i0' }
];
