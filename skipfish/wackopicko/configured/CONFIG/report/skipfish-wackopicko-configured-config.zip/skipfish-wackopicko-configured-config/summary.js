var sf_version = '2.10b';
var scan_date  = 'Sun Aug  5 01:35:02 2018';
var scan_seed  = '0x8543d1d6';
var scan_ms    = 1856517;
