var child = [
  { 'dupe': false, 'type': 128, 'name': 'home', 'dir': 'c0', 'linked': 0, 'url': 'http://192.168.0.26/WackoPicko/admin/index.php?page=home', 'fetched': true, 'code': 303, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xff7fffff },
  { 'dupe': false, 'type': 128, 'name': 'index', 'dir': 'c1', 'linked': 0, 'url': 'http://192.168.0.26/WackoPicko/admin/index.php?page=index', 'fetched': true, 'code': 200, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xff7fffff }
];
