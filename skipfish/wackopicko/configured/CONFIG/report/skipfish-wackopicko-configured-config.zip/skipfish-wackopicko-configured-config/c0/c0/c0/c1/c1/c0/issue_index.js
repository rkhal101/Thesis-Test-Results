var issue = [
  { 'severity': 0, 'type': 10405, 'sid': '0', 'extra': '', 'fetched': true, 'code': 303, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i0' }
];
