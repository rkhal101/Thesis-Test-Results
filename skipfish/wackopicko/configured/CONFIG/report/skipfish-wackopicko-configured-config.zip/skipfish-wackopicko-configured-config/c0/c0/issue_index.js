var issue = [
  { 'severity': 2, 'type': 30601, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10603, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i2' },
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-Powered-By', 'fetched': true, 'code': 200, 'len': 3482, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i3' },
  { 'severity': 0, 'type': 10201, 'sid': '0', 'extra': 'PHPSESSID', 'fetched': true, 'code': 200, 'len': 18, 'decl_mime': '[none]', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i4' }
];
