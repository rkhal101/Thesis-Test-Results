var issue = [
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 2281, 'decl_mime': 'text/css', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10801, 'sid': '0', 'extra': 'text/html', 'fetched': true, 'code': 200, 'len': 2281, 'decl_mime': 'text/css', 'sniff_mime': 'text/html', 'cset': '[none]', 'dir': 'i1' }
];
