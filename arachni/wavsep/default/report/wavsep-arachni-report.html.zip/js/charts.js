function index_to_shortname( index ){
    return ["file_inclusion","rfi","path_traversal","source_code_disclosure","sql_injection_differential","xss_script_context","xss","sql_injection_timing","no_sql_injection_differential","sql_injection","xss_event","xss_tag","csrf","unencrypted_password_forms","unvalidated_redirect","common_directories","private_ip","x_frame_options","password_autocomplete","common_files","http_only_cookies","interesting_responses"][index];
}

function index_to_severity( index ){
    return {"file_inclusion":"high","rfi":"high","path_traversal":"high","source_code_disclosure":"high","sql_injection_differential":"high","xss_script_context":"high","xss":"high","sql_injection_timing":"high","no_sql_injection_differential":"high","sql_injection":"high","xss_event":"high","xss_tag":"high","csrf":"high","unencrypted_password_forms":"medium","unvalidated_redirect":"medium","common_directories":"medium","private_ip":"low","x_frame_options":"low","password_autocomplete":"low","common_files":"low","http_only_cookies":"informational","interesting_responses":"informational"}[index_to_shortname(index)];
}

function renderCharts() {
    if( window.renderedCharts )
    window.renderedCharts = true;

    c3.generate({
        bindto: '#chart-issues',
        data: {
            columns: [
                ["Trusted",277,133,421,706,18,181,212,92,4,80,16,12,3,11,64,1,802,1,11,0,2,25],
                ["Untrusted",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0],
                ["Severity",4,4,4,4,4,4,4,4,4,4,4,4,4,3,3,3,2,2,2,2,1,1]
            ],
            axes: {
                Severity: 'y2'
            },
            type: 'bar',
            groups: [
                ['Trusted', 'Untrusted']
            ],
            types: {
                Severity: 'line'
            },
            onclick: function (d) {
                var location;

                if( d.name.toLowerCase() == 'severity' ) {
                    location = 'summary/issues/trusted/severity/' + index_to_severity(d.x);
                } else {
                    location = 'summary/issues/' + d.name.toLowerCase() + '/severity/' +
                        index_to_severity(d.x) + '/' + index_to_shortname(d.x);
                }

                goToLocation( location );
            }
        },
        regions: [{"class":"severity-high","start":0,"end":12},{"class":"severity-medium","start":13,"end":15},{"class":"severity-low","start":16,"end":19},{"class":"severity-informational","start":20}],
        axis: {
            x: {
                type: 'category',
                categories: ["File Inclusion","Remote File Inclusion","Path Traversal","Source code disclosure","Blind SQL Injection (differential analysis)","Cross-Site Scripting (XSS) in script context","Cross-Site Scripting (XSS)","Blind SQL Injection (timing attack)","Blind NoSQL Injection (differential analysis)","SQL Injection","Cross-Site Scripting (XSS) in event tag of HTML element","Cross-Site Scripting (XSS) in HTML tag","Cross-Site Request Forgery","Unencrypted password form","Unvalidated redirect","Common directory","Private IP address disclosure","Missing 'X-Frame-Options' header","Password field with auto-complete","Common sensitive file","HttpOnly cookie","Interesting response"],
                tick: {
                    rotate: 15
                }
            },
            y: {
                label: {
                    text: 'Amount of logged issues',
                    position: 'outer-center'
                }
            },
            y2: {
                label: {
                    text: 'Severity',
                    position: 'outer-center'
                },
                show: true,
                type: 'category',
                categories: [1, 2, 3, 4],
                tick: {
                    format: function (d) {
                        return ["Informational","Low","Medium","High"][d - 1]
                    }
                }
            }
        },
        padding: {
            bottom: 40
        },
        color: {
            pattern: [ '#1f77b4', '#d62728', '#ff7f0e' ]
        }
    });

    c3.generate({
        bindto: '#chart-trust',
        data: {
            type: 'pie',
            columns: [["Trusted",3072],["Untrusted",3]]
        },
        pie: {
            onclick: function (d) { goToLocation( 'summary/issues/' + d.id.toLowerCase() ) }
        },
        color: {
            pattern: [ '#1f77b4', '#d62728' ]
        }
    });

    c3.generate({
        bindto: '#chart-elements',
        data: {
            type: 'pie',
            columns: [["form",1338],["link",898],["cookie",7],["body",802],["server",30]]
        }
    });

    c3.generate({
        bindto: '#chart-severities',
        data: {
            type: 'pie',
            columns: [["high",2155],["medium",76],["low",817],["informational",27]]
        },
        color: {
            pattern: [ '#d62728', '#ff7f0e', '#ffbb78', '#1f77b4' ]
        },
        pie: {
            onclick: function (d) {
                goToLocation( 'summary/issues/trusted/severity/' + d.id );
            }
        }
    });

}
